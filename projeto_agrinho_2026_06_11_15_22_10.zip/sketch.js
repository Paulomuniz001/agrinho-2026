// Variáveis de controle do estado do jogo
let estadoJogo = "intro"; // Estados: "intro", "contagem", "jogando"
let tempoContagem = 3;
let frameInicialContagem = 0;

// Arrays para gerenciar as 3 plantas
let umidades = [60, 50, 70]; 
let tamanhos = [40, 40, 40]; 
let statusPlantas = ["viva", "viva", "viva"]; 
let causaMorte = ["", "", ""]; 

// Controle de tempo de colheita (frames)
let temposColheita = [600, 900, 1200]; 
let colhida = [false, false, false];

function setup() {
  createCanvas(700, 470);
}

function draw() {
  background(210, 235, 255); 
  
  if (estadoJogo === "intro") {
    desenharTelaIntro();
  } 
  else if (estadoJogo === "contagem") {
    desenharContagemRegressiva();
  } 
  else if (estadoJogo === "jogando") {
    executarJogo();
  }
}

// --- TELA DE INTRODUÇÃO ---
function desenharTelaIntro() {
  fill(255, 255, 255, 200);
  rect(50, 50, 600, 370, 15);
  
  fill(0);
  textAlign(CENTER);
  textStyle(BOLD);
  textSize(22);
  text("PROJETO AGRINHO", width / 2, 100);
  textSize(16);
  text("Tema: Agro Forte, Futuro Sustentável", width / 2, 130);
  
  textStyle(NORMAL);
  textSize(14);
  text("Bem-vindo ao Simulador de Manejo Hídrico Sustentável!", width / 2, 180);
  text("Sua missão é manter as 3 plantas com a umidade equilibrada.", width / 2, 210);
  text("Use o mouse para molhar os canteiros. Não deixe secar (0%) nem alagar (100%).", width / 2, 230);
  text("Cada espécie tem um tempo diferente para chegar à colheita!", width / 2, 250);
  
  // Botão Iniciar
  fill(34, 139, 34);
  rect(250, 310, 200, 50, 10);
  fill(255);
  textStyle(BOLD);
  textSize(16);
  text("COMEÇAR", width / 2, 340);
  
  textAlign(LEFT); 
  textStyle(NORMAL);
}

// --- CONTAGEM REGRESSIVA ---
function desenharContagemRegressiva() {
  let framesPassados = frameCount - frameInicialContagem;
  tempoContagem = 3 - floor(framesPassados / 60);
  
  desenharCenarioEstatico();
  
  fill(0, 0, 0, 100);
  rect(0, 0, width, height);
  
  fill(255, 215, 0);
  textAlign(CENTER, CENTER);
  textSize(80);
  textStyle(BOLD);
  
  if (tempoContagem > 0) {
    text(tempoContagem, width / 2, height / 2);
  } else {
    text("PREPARAR... JÁ!", width / 2, height / 2);
  }
  
  if (framesPassados >= 200) {
    estadoJogo = "jogando";
  }
  
  textAlign(LEFT, BASELINE); 
  textStyle(NORMAL);
}

// --- DETECÇÃO DE CLIQUES (BOTÕES) ---
function mousePressed() {
  if (estadoJogo === "intro") {
    if (mouseX > 250 && mouseX < 450 && mouseY > 310 && mouseY < 360) {
      estadoJogo = "contagem";
      frameInicialContagem = frameCount; 
    }
  }
  
  if (estadoJogo === "jogando") {
    let todasColhidas = colhida[0] && colhida[1] && colhida[2];
    let algumaMorta = statusPlantas[0] === "morta" || statusPlantas[1] === "morta" || statusPlantas[2] === "morta";
    
    if (todasColhidas || algumaMorta) {
      if (mouseX > 530 && mouseX < 670 && mouseY > 110 && mouseY < 140) {
        reiniciarJogo();
      }
    }
  }
}

// --- FUNÇÃO PARA REINICIAR AS VARIÁVEIS ---
function reiniciarJogo() {
  umidades = [60, 50, 70]; 
  tamanhos = [40, 40, 40]; 
  statusPlantas = ["viva", "viva", "viva"]; 
  causaMorte = ["", "", ""]; 
  temposColheita = [600, 900, 1200]; 
  colhida = [false, false, false];
  
  estadoJogo = "contagem";
  frameInicialContagem = frameCount; 
}

// --- FUNÇÃO PRINCIPAL DO JOGO (CORRIGIDA) ---
function executarJogo() {
  fill(0);
  noStroke();
  textSize(18);
  textStyle(BOLD);
  text("SIMULADOR: AGRO FORTE, FUTURO SUSTENTÁVEL", 20, 35);
  
  textSize(13);
  textStyle(NORMAL);
  text("Desafio: Cuide das plantas com equilíbrio até a hora da COLHEITA!", 20, 60);
  text("Use o mouse para irrigar. Evite a SECA (0%) e o ENCHARCAMENTO (100%).", 20, 80);

  for (let i = 0; i < 3; i++) {
    if (statusPlantas[i] === "viva" && temposColheita[i] > 0) {
      umidades[i] -= (0.12 + i * 0.04); 
      temposColheita[i]--; 
    }
    
    if (temposColheita[i] <= 0 && statusPlantas[i] === "viva") {
      colhida[i] = true;
    }
    
    if (umidades[i] <= 0) {
      umidades[i] = 0;
      statusPlantas[i] = "morta";
      causaMorte[i] = "seca";
    }
    if (umidades[i] >= 100) {
      umidades[i] = 100;
      statusPlantas[i] = "morta";
      causaMorte[i] = "encharcada";
    }
  }

  desenharCenarioEstatico();
  
  let todasColhidas = colhida[0] && colhida[1] && colhida[2];
  let algumaMorta = statusPlantas[0] === "morta" || statusPlantas[1] === "morta" || statusPlantas[2] === "morta";
  
  stroke(0);
  strokeWeight(1);
  
  if (todasColhidas) {
    fill(100, 255, 100); 
    rect(20, 105, 660, 40, 5);
    fill(0, 80, 0);
    textStyle(BOLD);
    text("SUCESSO TOTAL! Lavoura 100% sustentável! 🌻🌸💠", 35, 130);
    
    fill(0, 120, 0);
    rect(530, 110, 140, 30, 5);
    fill(255);
    textSize(11);
    textAlign(CENTER, CENTER);
    text("JOGAR DE NOVO", 600, 125);
    textAlign(LEFT, BASELINE);
  } 
  else if (algumaMorta) {
    fill(255, 200, 200); 
    rect(20, 105, 660, 40, 5);
    fill(150, 0, 0);
    textStyle(BOLD);
    text("FALHA NO EQUILÍBRIO: Manejo incorreto.", 35, 130);
    
    fill(180, 0, 0);
    rect(530, 110, 140, 30, 5);
    fill(255);
    textSize(11);
    textAlign(CENTER, CENTER);
    text("TENTE NOVAMENTE", 600, 125);
    textAlign(LEFT, BASELINE);
  } 
  else {
    fill(255, 245, 200);
    rect(20, 105, 660, 40, 5);
    fill(100, 80, 0);
    textStyle(BOLD);
    text("MANEJO ATIVO: Alterne a irrigação entre os canteiros!", 35, 130);
  }
  textStyle(NORMAL); 
}

// --- CENÁRIO REUTILIZÁVEL (TERRA E PLANTAS) ---
function desenharCenarioEstatico() {
  for (let i = 0; i < 3; i++) {
    let xCanteiro = i * 233;
    
    let corSolo = map(umidades[i], 0, 100, 190, 50);
    fill(corSolo, corSolo * 0.5, 30);
    rect(xCanteiro, 340, 234, 130);
    
    stroke(255, 40);
    line(xCanteiro, 340, xCanteiro, 470);
    
    if (estadoJogo === "jogando" && mouseIsPressed && mouseX > xCanteiro && mouseX < xCanteiro + 233 && mouseY > 120) {
      let algumaMorta = statusPlantas[0] === "morta" || statusPlantas[1] === "morta" || statusPlantas[2] === "morta";
      let todasColhidas = colhida[0] && colhida[1] && colhida[2];
      
      if (statusPlantas[i] === "viva" && !colhida[i] && !algumaMorta && !todasColhidas) {
        umidades[i] += 1.4; 
        fill(0, 120, 255);
        noStroke();
        ellipse(mouseX, mouseY, 6, 10);
        ellipse(mouseX + 12, mouseY + 8, 5, 8);
      }
    }
    
    let xPlanta = xCanteiro + 116; 
    let algumaMorta = statusPlantas[0] === "morta" || statusPlantas[1] === "morta" || statusPlantas[2] === "morta";
    
    if (statusPlantas[i] === "viva") {
      if (umidades[i] >= 40 && umidades[i] <= 80) {
        fill(34, 139, 34); 
        if (tamanhos[i] < 120 && estadoJogo === "jogando" && !algumaMorta) tamanhos[i] += 0.4; 
      } else {
        fill(180, 160, 50); 
      }
      
      stroke(0, 100, 0);
      strokeWeight(4);
      line(xPlanta, 340, xPlanta, 340 - tamanhos[i]);
      
      noStroke();
      if (i === 0) {
        ellipse(xPlanta - 12, 360 - tamanhos[i], 18, 14);
        ellipse(xPlanta + 12, 360 - tamanhos[i], 18, 14);
      } else if (i === 1) {
        triangle(xPlanta, 355 - tamanhos[i], xPlanta - 20, 365 - tamanhos[i], xPlanta, 370 - tamanhos[i]);
        triangle(xPlanta, 355 - tamanhos[i], xPlanta + 20, 365 - tamanhos[i], xPlanta, 370 - tamanhos[i]);
      } else if (i === 2) {
        ellipse(xPlanta - 10, 355 - tamanhos[i], 10, 8);
        ellipse(xPlanta - 12, 365 - tamanhos[i], 12, 8);
        ellipse(xPlanta + 10, 355 - tamanhos[i], 10, 8);
        ellipse(xPlanta + 12, 365 - tamanhos[i], 12, 8);
      }

      if (colhida[i]) {
        push();
        translate(xPlanta, 340 - tamanhos[i]);
        if (i === 0) {
          fill(255, 215, 0);
          for (let p = 0; p < 8; p++) { rotate(PI/4); ellipse(0, 15, 10, 22); }
          fill(100, 50, 0); ellipse(0, 0, 18, 18);
        } else if (i === 1) {
          fill(255, 20, 147);
          for (let p = 0; p < 5; p++) { rotate(2 * PI / 5); ellipse(0, 12, 14, 16); }
          fill(255, 255, 100); ellipse(0, 0, 12, 12);
        } else if (i === 2) {
          fill(0, 206, 209);
          for (let p = 0; p < 6; p++) { rotate(PI/3); rect(-6, 8, 12, 15, 4); }
          fill(255); ellipse(0, 0, 14, 14);
        }
        pop();
      } else {
        fill(100, 200, 50);
        ellipse(xPlanta, 340 - tamanhos[i], 16, 16);
      }
      
    } else {
      if (causaMorte[i] === "encharcada") {
        stroke(50, 60, 40); strokeWeight(4);
        line(xPlanta, 340, xPlanta + 25, 320);
        noStroke(); fill(85, 65, 45);
        ellipse(xPlanta + 25, 320, 25, 15);
        fill(200, 0, 0); textSize(11); textAlign(CENTER);
        text("SISTEMA ALAGADO:\nRAÍZES PODRES", xPlanta, 380);
      } else if (causaMorte[i] === "seca") {
        stroke(120, 90, 60); strokeWeight(3);
        line(xPlanta, 340, xPlanta - 10, 310);
        line(xPlanta - 10, 310, xPlanta - 5, 290);
        noStroke(); fill(200, 0, 0); textSize(11); textAlign(CENTER);
        text("SOLO DESÉRTICO:\nMORREU DE SEDE", xPlanta, 380);
      }
      textAlign(LEFT);
    }
    
    noStroke(); fill(255); textSize(11);
    text("Canteiro " + (i + 1), xCanteiro + 15, 405);
    text("Umidade: " + floor(umidades[i]) + "%", xCanteiro + 15, 423);
    
    if (statusPlantas[i] === "morta") {
      text("Status: Perdido", xCanteiro + 15, 442);
    } else if (colhida[i]) {
      fill(100, 255, 100); text("Status: PRONTA!", xCanteiro + 15, 442);
    } else {
      text("Colheita em: " + ceil(temposColheita[i]/60) + "s", xCanteiro + 15, 442);
    }
  }
}